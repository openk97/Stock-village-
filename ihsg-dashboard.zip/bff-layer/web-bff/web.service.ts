import { WebDashboardAggregateDTO, WebIHSGSummaryDTO, WebNewsDTO, WebSectorDTO } from "./web.dto";

export class WebBffService {
  // Definisikan alamat internal port microservices (Infrastructure Layer)
  private readonly IHSG_SERVICE_URL = process.env.IHSG_SERVICE_URL || "http://localhost:8001/api";
  private readonly NEWS_SERVICE_URL = process.env.NEWS_SERVICE_URL || "http://localhost:8002/api";
  private readonly SECTOR_SERVICE_URL = process.env.SECTOR_SERVICE_URL || "http://localhost:8003/api";

  /**
   * Mengumpulkan dan menggabungkan data dari berbagai microservices secara paralel
   * guna memangkas jumlah request dari Web Browser ke server (mencegah Under-fetching)
   */
  async getDashboardData(period: string = "1y"): Promise<WebDashboardAggregateDTO> {
    try {
      // Eksekusi pemanggilan HTTP paralel ke seluruh Microservices backend
      const [ihsgRealtimeRes, ihsgHistoryRes, newsRes, sectorsRes, sentimentRes] = await Promise.all([
        fetch(`${this.IHSG_SERVICE_URL}/ihsg/realtime`).then(res => res.json()).catch(() => this.getFallbackRealtime()),
        fetch(`${this.IHSG_SERVICE_URL}/ihsg/history?period=${period}`).then(res => res.json()).catch(() => []),
        fetch(`${this.NEWS_SERVICE_URL}/news`).then(res => res.json()).catch(() => []),
        fetch(`${this.SECTOR_SERVICE_URL}/sectors`).then(res => res.json()).catch(() => []),
        fetch(`${this.NEWS_SERVICE_URL}/sentiment`).then(res => res.json()).catch(() => ({ score: 50, sentiment_label: "Neutral" }))
      ]);

      // 1. Transformasi Data IHSG ke Format DTO Web (Format Volume menjadi string "B/M")
      const ihsgFormatted: WebIHSGSummaryDTO = {
        price: ihsgRealtimeRes.current_price,
        change: ihsgRealtimeRes.change,
        changePercent: ihsgRealtimeRes.change_percent,
        open: ihsgRealtimeRes.open,
        high: ihsgRealtimeRes.high,
        low: ihsgRealtimeRes.low,
        volume: this.formatVolumeToString(ihsgRealtimeRes.volume),
        status: "Active",
        lastUpdated: ihsgRealtimeRes.last_updated
      };

      // 2. Transformasi Berita Keuangan (Membatasi hanya maksimal 5 berita untuk tampilan web)
      const newsFormatted: WebNewsDTO[] = newsRes.slice(0, 5).map((n: any) => ({
        id: n.id,
        title: n.title,
        url: n.url,
        source: n.source,
        sentiment: n.sentiment,
        publishedAt: n.published_at
      }));

      // 3. Transformasi Sektoral & Menghitung apakah sektor mengalahkan kinerja IHSG harian (Outperform)
      const ihsgDailyChange = ihsgFormatted.changePercent;
      const sectorsFormatted: WebSectorDTO[] = sectorsRes.map((s: any) => ({
        name: s.sector_name,
        changePercent: s.change_percent,
        isOutperforming: s.change_percent > ihsgDailyChange
      }));

      // 4. Gabungkan seluruh data hasil transformasi ke dalam satu kesatuan DTO Komprehensif
      return {
        ihsg: ihsgFormatted,
        chartHistory: ihsgHistoryRes,
        news: newsFormatted,
        sectors: sectorsFormatted,
        sentimentScore: sentimentRes.score,
        sentimentLabel: sentimentRes.sentiment_label
      };

    } catch (error) {
      console.error("BFF Web Service Error saat agregasi data:", error);
      throw new Error("Gagal melakukan agregasi data bursa di lapisan BFF.");
    }
  }

  // Helper untuk mengubah angka volume mentah menjadi format ringkas (e.g. 14.2B)
  private formatVolumeToString(vol: number): string {
    if (vol >= 1e9) return (vol / 1e9).toFixed(1) + "B";
    if (vol >= 1e6) return (vol / 1e6).toFixed(1) + "M";
    return vol.toLocaleString("id-ID");
  }

  // Fallback Data jika Microservice internal offline
  private getFallbackRealtime() {
    return {
      current_price: 7245.50,
      change: 34.20,
      change_percent: 0.47,
      open: 7211.30,
      high: 7260.10,
      low: 7208.50,
      volume: 14200000000,
      last_updated: new Date().toISOString()
    };
  }
}
