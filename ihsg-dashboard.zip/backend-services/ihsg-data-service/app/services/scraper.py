import yfinance as yf
import pandas as pd
from datetime import datetime, timedelta
from typing import List, Dict, Any
from sqlalchemy.orm import Session
from app.models import IHSGHistory, NewsArticle, SectorPerformance

class IHSGScraper:
    @staticmethod
    def fetch_and_sync_history(db: Session, period: str = "1y") -> List[Dict[str, Any]]:
        """
        Mengambil data historis IHSG (^JKSE) dari Yahoo Finance, menghitung indikator teknikal,
        menyimpannya (atau memperbarui) di database SQLite/PostgreSQL, dan mengembalikan data yang bersih.
        """
        ticker = "^JKSE"
        try:
            df = yf.download(tickers=ticker, period=period, interval="1d")
            if df.empty:
                # Fallback ke database jika Yahoo Finance gagal/offline
                return IHSGScraper.get_history_from_db(db)

            df = df.reset_index()

            # Menghitung indikator teknikal menggunakan Pandas
            df['SMA_50'] = df['Close'].rolling(window=50).mean()
            df['SMA_200'] = df['Close'].rolling(window=200).mean()
            
            # Relative Strength Index (RSI)
            delta = df['Close'].diff()
            gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
            rs = gain / (loss + 1e-10)
            df['RSI_14'] = 100 - (100 / (1 + rs))

            df = df.fillna(0)

            # Menyimpan/Sinkronisasi ke Database
            for _, row in df.iterrows():
                date_str = row['Date'].strftime('%Y-%m-%d')
                
                # Cek apakah record sudah ada di database
                db_record = db.query(IHSGHistory).filter(IHSGHistory.date == date_str).first()
                
                if db_record:
                    # Update jika sudah ada
                    db_record.open = float(row['Open'])
                    db_record.high = float(row['High'])
                    db_record.low = float(row['Low'])
                    db_record.close = float(row['Close'])
                    db_record.volume = float(row['Volume'])
                    db_record.sma_50 = float(row['SMA_50'])
                    db_record.sma_200 = float(row['SMA_200'])
                    db_record.rsi_14 = float(row['RSI_14'])
                else:
                    # Buat baru jika belum ada
                    new_record = IHSGHistory(
                        date=date_str,
                        open=float(row['Open']),
                        high=float(row['High']),
                        low=float(row['Low']),
                        close=float(row['Close']),
                        volume=float(row['Volume']),
                        sma_50=float(row['SMA_50']),
                        sma_200=float(row['SMA_200']),
                        rsi_14=float(row['RSI_14'])
                    )
                    db.add(new_record)
            
            db.commit()
            return IHSGScraper.get_history_from_db(db)

        except Exception as e:
            print(f"Error syncing IHSG history: {str(e)}")
            return IHSGScraper.get_history_from_db(db)

    @staticmethod
    def get_history_from_db(db: Session) -> List[Dict[str, Any]]:
        """
        Mengambil data historis langsung dari Database lokal.
        """
        records = db.query(IHSGHistory).order_by(IHSGHistory.date.asc()).all()
        return [
            {
                "date": r.date,
                "open": r.open,
                "high": r.high,
                "low": r.low,
                "close": r.close,
                "volume": r.volume,
                "sma_50": r.sma_50,
                "sma_200": r.sma_200,
                "rsi_14": r.rsi_14
            }
            for r in records
        ]

    @staticmethod
    def get_realtime_status() -> Dict[str, Any]:
        """
        Mengambil status pasar IHSG real-time / delayed 15 menit dari Yahoo Finance.
        """
        ticker = yf.Ticker("^JKSE")
        try:
            history = ticker.history(period="5d")
            if len(history) < 2:
                # Mock fallback jika bursa belum buka/error
                return IHSGScraper._get_mock_realtime()

            last_close = history['Close'].iloc[-1]
            prev_close = history['Close'].iloc[-2]
            change = last_close - prev_close
            change_percent = (change / prev_close) * 100

            return {
                "name": "Indeks Harga Saham Gabungan (IHSG)",
                "symbol": "^JKSE",
                "current_price": float(last_close),
                "previous_close": float(prev_close),
                "open": float(history['Open'].iloc[-1]),
                "high": float(history['High'].iloc[-1]),
                "low": float(history['Low'].iloc[-1]),
                "volume": int(history['Volume'].iloc[-1]),
                "change": float(change),
                "change_percent": float(change_percent),
                "last_updated": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        except Exception as e:
            print(f"Error getting real-time status: {str(e)}")
            return IHSGScraper._get_mock_realtime()

    @staticmethod
    def _get_mock_realtime() -> Dict[str, Any]:
        """Fallback mock data jika koneksi internet terganggu."""
        return {
            "name": "Indeks Harga Saham Gabungan (IHSG)",
            "symbol": "^JKSE",
            "current_price": 7245.50,
            "previous_close": 7211.30,
            "open": 7211.30,
            "high": 7260.10,
            "low": 7208.50,
            "volume": 14200000000,
            "change": 34.20,
            "change_percent": 0.47,
            "last_updated": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

    @staticmethod
    def seed_initial_data(db: Session):
        """
        Inisialisasi data awal (seeding) untuk Berita dan Sektor jika database masih kosong.
        Ini memastikan user langsung melihat data dinamis di dashboard.
        """
        # 1. Seeding Berita (News Seeding)
        if db.query(NewsArticle).count() == 0:
            news_items = [
                NewsArticle(
                    title="BI Pertahankan Suku Bunga di 6.00%, Pasar Merespon Positif",
                    url="https://cnbcindonesia.com/market/bi-suku-bunga-6",
                    source="CNBC Indonesia",
                    sentiment="Positive",
                    score=0.85,
                    published_at="10 Menit Lalu"
                ),
                NewsArticle(
                    title="Laba Bersih BCA (BBCA) Kuartal II Melampaui Estimasi Konsensus",
                    url="https://bisnis.com/market/laba-bca-q2",
                    source="Bisnis.com",
                    sentiment="Positive",
                    score=0.90,
                    published_at="1 Jam Lalu"
                ),
                NewsArticle(
                    title="Bursa Saham Wall Street Ditutup Koreksi Imbas Rilis Data Tenaga Kerja AS",
                    url="https://kontan.co.id/global/wall-street-koreksi",
                    source="Kontan",
                    sentiment="Negative",
                    score=-0.65,
                    published_at="3 Jam Lalu"
                ),
                NewsArticle(
                    title="Sektor Energi Tertekan Penurunan Harga Komoditas Minyak Mentah Global",
                    url="https://kontan.co.id/market/sektor-energi-turun",
                    source="Kontan",
                    sentiment="Negative",
                    score=-0.45,
                    published_at="5 Jam Lalu"
                ),
                NewsArticle(
                    title="Asing Catat Net Buy Rp 500 Miliar Terutama di Saham Big Banks",
                    url="https://cnbcindonesia.com/market/net-buy-asing-big-banks",
                    source="CNBC Indonesia",
                    sentiment="Positive",
                    score=0.78,
                    published_at="6 Jam Lalu"
                )
            ]
            db.bulk_save_objects(news_items)

        # 2. Seeding Sektoral (Sector Seeding)
        if db.query(SectorPerformance).count() == 0:
            sectors = [
                SectorPerformance(sector_name="1. Finansial (IDXFIN)", change_percent=1.24),
                SectorPerformance(sector_name="2. Infrastruktur (IDXINFRA)", change_percent=0.87),
                SectorPerformance(sector_name="3. Properti (IDXPROPERT)", change_percent=0.45),
                SectorPerformance(sector_name="4. Konsumer Primer (IDXNONCYC)", change_percent=0.12),
                SectorPerformance(sector_name="5. Energi (IDXENERGY)", change_percent=-0.42),
                SectorPerformance(sector_name="6. Teknologi (IDXTECHNO)", change_percent=-1.15)
            ]
            db.bulk_save_objects(sectors)
        
        db.commit()
